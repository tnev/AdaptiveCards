//
//  ACRColumnSetView
//  ACRColumnSetView.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//
#import "ACRContentStackView.h"

@interface ACRColumnSetView:ACRContentStackView

- (void)setAlignmentForColumnStretch;

@end
