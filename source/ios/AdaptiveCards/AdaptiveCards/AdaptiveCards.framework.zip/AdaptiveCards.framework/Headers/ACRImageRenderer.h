//
//  ACRImageRenderer
//  ACRImageRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseCardElementRenderer.h"

@interface ACRImageRenderer:ACRBaseCardElementRenderer

+ (ACRImageRenderer *)getInstance;

@end
