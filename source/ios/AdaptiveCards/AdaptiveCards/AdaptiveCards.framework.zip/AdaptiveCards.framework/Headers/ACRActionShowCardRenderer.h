//
//  ACRActionShowCardRenderer
//  ACRActionShowCardRenderer.h
//
//  Copyright © 2017 Microsoft. All rights reserved.
//

#import "ACRBaseActionElementRenderer.h"

@interface ACRActionShowCardRenderer:ACRBaseActionElementRenderer

+ (ACRActionShowCardRenderer *)getInstance;

@end
