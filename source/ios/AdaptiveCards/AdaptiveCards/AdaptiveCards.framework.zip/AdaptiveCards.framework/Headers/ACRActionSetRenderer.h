//
//  ACRActionSetRenderer
//  ACRActionSetRenderer.h
//
//  Copyright © 2018 Microsoft. All rights reserved.
//

#import "ACRBaseActionElementRenderer.h"

@interface ACRActionSetRenderer:NSObject<ACRIBaseActionSetRenderer>

+ (ACRActionSetRenderer *)getInstance;

@end
